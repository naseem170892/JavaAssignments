package com.exilant.assignment3;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

@SuppressWarnings("not-use")

public class KBC {

	String questions, options, answer, enter;
	char ch;
	int i, correct = 0;
	KBC[] quiz = new KBC[4];
	int count = 0;

	// KbcQuizStart
	public void KbcStart() {
		for (i = 0; i < 4; i++) {
			quiz[i] = new KBC();
		}

	}

	// kbcQuizMcq
	public void kbcQuiz() {
		try {
			quiz[0].questions = "Who among the following has become the fastest to score 12,000 runs in Test matches?";
			quiz[1].questions = "Which among the following countries has the world’s largest and most important tar oil sands deposits?";
			quiz[2].questions = "The United Nations Children’s Fund (UNICEF) has decided to prepare a Tea Atlas in which one of the following states?";
			quiz[3].questions = "The 2016 UEFA European Championship or Euro 2016 for men’s national football teams will be hosted by which country?";

		} catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			System.err.println("Error Occur!\n" + e.getMessage());
			System.exit(0);
		}
	}

	// kbcQuizMcqOptions
	public void kbcQuizMcqOptions() {
		try {
			quiz[0].options = " A.Mahela Jayawardene \n B. Kumar Sangakkara\n C.Shane Watson\n D.Hashim Amla";
			quiz[1].options = " A.Russia\n B.Venezuela \n C.Canada\n D.Kazakhstan";
			quiz[2].options = " A.Tamil Nadu \n B.Kerala \n C.Karnataka\n D.Assam";
			quiz[3].options = " A.Italy \n B.Greece \n C.France\n D.Switzerland";
		} catch (ArrayIndexOutOfBoundsException e) {
			System.err.println("Error Occur!\n" + e.getMessage());
			System.exit(0);
		}
	}
	// kbcQuizMcqAnswers

	public void kbcQuizMcqAnswers() {
		quiz[0].answer = "B";
		quiz[1].answer = "C";
		quiz[2].answer = "D";
		quiz[3].answer = "C";

	}

	public void runKbcQuiz() {
		try {
			Scanner scan = new Scanner(System.in);
			String temp = "";

			for (i = 0; i < 4; i++) {
				System.out.println("............................................................");
				System.out.println("Question " + (i + 1) + ": " + quiz[i].questions + "\n" + quiz[i].options);
				System.out.printf("Enter Your Answer:" + "\n");

				temp = scan.next();
				ch = temp.charAt(0);
				temp = Character.toString(ch);

				if (temp.equalsIgnoreCase(quiz[i].answer)) {
					System.out.println("*************************************************************");
					System.out.println("Question " + (i + 1));
					System.out.println("Entered Answer is CORRECT");
					correct++;
					System.out.println("*************************************************************");

				} else {
					System.out.println("*************************************************************");
					System.out.println("Question " + (i + 1));
					System.out.println("Entered Answer is WRONG");
					System.out.println("Correct Answer is: " + quiz[i].answer);
					System.out.println("*************************************************************");
				}

			}
		}

		catch (ArrayIndexOutOfBoundsException e) {
			System.err.println("Error Occur3c!\n" + e.getMessage());
			System.exit(0);
		} catch (InputMismatchException e) {
			System.err.println("Error Occur1!\n" + e.getMessage());
			System.exit(0);
		}
	}

	// Result Validation
	public void KbcQuizAssessments() {

		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		System.out.println("------------------ Your Score is:- -----------------------");
		System.out.println(
				"You answered 4 questions out of \n" + correct + " Correct and \n" + (4 - correct) + " Incorrect!");
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

	}

	public static void main(String[] args) {

		System.out.println("Name:Vikas");
		KBC Object = new KBC();
		Object.KbcStart();
		Object.kbcQuiz();
		Object.kbcQuizMcqOptions();
		Object.kbcQuizMcqAnswers();
		Object.runKbcQuiz();
		Object.KbcQuizAssessments();
	}

}
