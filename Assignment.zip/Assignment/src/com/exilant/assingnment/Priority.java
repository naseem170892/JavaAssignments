package com.exilant.assingnment;

import java.util.PriorityQueue;



public class Priority {
	
	public static void main(String[] args) {
		
		 PriorityQueue<Mobile> deviceList = new PriorityQueue<>(10, new SortingMobile.sortByDecID());
		 deviceList.add(new Mobile("Sony",13000));
		 deviceList.add(new Mobile("Samsung", 35000));
		 deviceList.add(new Mobile("Lenovo", 50000));
		 deviceList.add(new Mobile("Micromax",2000));
		 System.out.println("Mobiles in decreasing order   : \n");

		 for (Mobile device : deviceList) {
			System.out.println(device.getName() + "\t\t"+device.getRate());
		}
		
		}
}
