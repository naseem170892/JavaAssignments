package com.exilant.assingnment;

import java.util.Comparator;

public class SortingMobile {
	public static class sortByDecID implements Comparator<Mobile> {

		@Override
		public int compare(Mobile o1, Mobile o2) {
			// TODO Auto-generated method stub
			return o2.getRate() - o1.getRate();
		}
	}

	public class sortByIncID implements Comparator<Mobile> {

		@Override
		public int compare(Mobile o1, Mobile o2) {
			// TODO Auto-generated method stub
			return o1.getRate() - o2.getRate();
		}

	}

	public class sortByIncName implements Comparator<Mobile> {

		@Override
		public int compare(Mobile o1, Mobile o2) {
			// TODO Auto-generated method stub
			return o1.getName().compareTo(o2.getName());
		}

	}

	public class sortByDecName implements Comparator<Mobile> {

		@Override
		public int compare(Mobile o1, Mobile o2) {
			// TODO Auto-generated method stub
			return o2.getName().compareTo(o1.getName());
		}

	}

}
